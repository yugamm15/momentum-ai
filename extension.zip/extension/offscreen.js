const PROCESS_UPLOAD_URL = "https://momentum-ai-meet.vercel.app/api/store-meeting-audio";
const CHUNK_TIMESLICE_MS = 5000;
const ENGINE_START_TIMEOUT_MS = 12000;
const SUPABASE_URL = "https://irrczdmajazxwnjmrgtk.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_xkmC5OFqgHdFL8zwzqUE5g__q5yycaq";

const DB_NAME = "momentum-recordings";
const DB_VERSION = 1;
const SESSION_STORE = "sessions";
const CHUNK_STORE = "chunks";

let activeSession = null;

chrome.runtime.sendMessage({
  type: "OFFSCREEN_READY",
}).catch(() => {});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target !== "offscreen") {
    if (message.type === "OFFSCREEN_PING") {
      chrome.runtime.sendMessage({ type: "OFFSCREEN_READY" }).catch(() => {});
    }
    return false;
  }

  if (message.type === "START_RECORDING") {
    startRecordingSession(message).catch(async (error) => {
      const failedTabId = activeSession?.tabId || message.tabId;
      cleanupLiveSession();
      chrome.runtime.sendMessage({
        type: "OFFSCREEN_RECORDING_ERROR",
        tabId: failedTabId,
        error: error.message,
        detail: "Momentum could not start capturing this Meet tab.",
      });
    });
    return false;
  }

  if (message.type === "STOP_RECORDING") {
    stopRecordingSession(message.reason).catch(async (error) => {
      chrome.runtime.sendMessage({
        type: "OFFSCREEN_PROCESSING_FAILED",
        tabId: activeSession?.tabId,
        error: error.message,
        detail: "Momentum hit an unexpected problem while sealing the local audio copy.",
      });
      cleanupLiveSession();
    });
    return false;
  }

  if (message.type === "PROCESS_PENDING_UPLOADS") {
    recoverPendingSessions()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === "GET_PENDING_UPLOAD_SUMMARY") {
    getPendingUploadSummary()
      .then((summary) => sendResponse({ ok: true, summary }))
      .catch((error) => sendResponse({ ok: false, error: error.message, summary: emptySummary() }));
    return true;
  }

  return false;
});

async function startRecordingSession({ streamId, tabId, meetingCode, meetingUrl }) {
  if (activeSession) {
    throw new Error("A meeting is already being captured.");
  }

  let sessionId = "";

  try {
    const stream = await withTimeout(
      navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId,
        },
      },
      video: false,
      }),
      ENGINE_START_TIMEOUT_MS,
      "Chrome granted capture, but the meeting audio stream never opened."
    );

    const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
      ? "audio/webm;codecs=opus"
      : "audio/webm";
    const recorder = new MediaRecorder(stream, { mimeType });

    let resolveStop;
    let rejectStop;
    const stopPromise = new Promise((resolve, reject) => {
      resolveStop = resolve;
      rejectStop = reject;
    });

    sessionId = crypto.randomUUID();
    activeSession = {
      sessionId,
      tabId,
      meetingCode,
      meetingUrl,
      mimeType,
      stream,
      recorder,
      pendingWrites: new Set(),
      chunkIndex: 0,
      stopPromise,
      resolveStop,
      rejectStop,
      state: "recording",
      finalError: null,
    };

    await upsertStoredSession({
      sessionId,
      tabId,
      meetingCode,
      meetingUrl,
      mimeType,
      chunkCount: 0,
      state: "recording",
      createdAt: Date.now(),
      updatedAt: Date.now(),
      lastError: "",
    });

    await reportQueueSummary();

    recorder.ondataavailable = (event) => {
      if (!event.data || event.data.size === 0 || !activeSession) {
        return;
      }

      persistChunk(event.data).catch((error) => {
        if (activeSession) {
          activeSession.finalError = error;
        }

        if (recorder.state === "recording") {
          recorder.stop();
        }
      });
    };

    recorder.onerror = (event) => {
      rejectStop(new Error(event.error?.message || "Chrome failed to capture tab audio."));
    };

    recorder.onstop = async () => {
      const session = activeSession;

      try {
        await waitForPendingWrites(session);

        if (session?.finalError) {
          throw session.finalError;
        }

        if (!session) {
          throw new Error("Momentum lost the live recording state.");
        }

        await notifyProgress(session.tabId, {
          phase: "processing",
          status: "Audio saved locally. Building final upload...",
          detail: `${session.chunkIndex} recovery chunk${session.chunkIndex === 1 ? "" : "s"} are sealed on this device.`,
          stage: "packaging",
          terminal: false,
          sessionId: session.sessionId,
          chunkCount: session.chunkIndex,
          savedLocally: session.chunkIndex > 0,
          retryPending: false,
          lastError: "",
        });

        await updateStoredSessionState(session.sessionId, "uploading", { lastError: "" });
        await reportQueueSummary();

        await notifyProgress(session.tabId, {
          phase: "processing",
          status: "Uploading saved audio to Supabase...",
          detail: `${session.chunkIndex} local chunk${session.chunkIndex === 1 ? "" : "s"} merged into one upload.`,
          stage: "uploading",
          terminal: false,
          sessionId: session.sessionId,
          chunkCount: session.chunkIndex,
          savedLocally: true,
          retryPending: false,
          lastError: "",
        });

        const result = await uploadStoredSession(session.sessionId);

        session.resolveStop();
        chrome.runtime.sendMessage({
          type: "OFFSCREEN_PROCESSING_COMPLETE",
          tabId: session.tabId,
          meetingId: result.meetingId,
          status: result.meetingTitle ? `Audio saved: ${result.meetingTitle}` : "Meeting audio saved to Supabase.",
          detail:
            result.storageMode === "bucket"
              ? "The combined meeting audio is stored in Supabase Storage."
              : "The combined meeting audio is stored directly inside Supabase for now.",
        });
      } catch (error) {
        if (session?.sessionId) {
          await markSessionForRetry(session.sessionId, error.message);
          await reportQueueSummary();

          session?.rejectStop(error);
          chrome.runtime.sendMessage({
            type: "OFFSCREEN_PROCESSING_DEFERRED",
            tabId: session?.tabId,
            sessionId: session.sessionId,
            chunkCount: session.chunkIndex,
            error: error.message,
            status: "Audio saved locally. Sync will retry automatically.",
            detail:
              "Momentum kept this meeting on your device because the Supabase upload did not finish. Reopen Chrome or keep it open to retry.",
          });
        } else {
          session?.rejectStop(error);
          chrome.runtime.sendMessage({
            type: "OFFSCREEN_PROCESSING_FAILED",
            tabId: session?.tabId,
            error: error.message,
            detail: "Momentum could not keep a recoverable local copy for retry.",
          });
        }
      } finally {
        cleanupLiveSession();
      }
    };

    for (const track of stream.getTracks()) {
      track.addEventListener("ended", () => {
        if (activeSession?.state === "recording") {
          stopRecordingSession("Capture ended. Sending audio to Supabase...").catch(() => {});
        }
      });
    }

    recorder.start(CHUNK_TIMESLICE_MS);

    chrome.runtime.sendMessage({
      type: "OFFSCREEN_RECORDING_STARTED",
      tabId,
      sessionId,
      chunkCount: 0,
      savedLocally: false,
      detail: "Saving secure 5-second recovery chunks on this device while you stay in the meeting.",
    });
  } catch (error) {
    if (sessionId) {
      await clearStoredSession(sessionId).catch(() => {});
      await reportQueueSummary();
    }

    cleanupLiveSession();
    throw error;
  }
}

async function stopRecordingSession(statusMessage) {
  if (!activeSession) {
    return;
  }

  if (activeSession.state !== "recording") {
    return activeSession.stopPromise;
  }

  activeSession.state = "processing";
  await notifyProgress(activeSession.tabId, {
    phase: "processing",
    status: statusMessage || "Finalizing captured audio...",
    detail: "Momentum is closing the recorder and preserving the local audio copy before upload.",
    stage: "stopping",
    terminal: false,
    sessionId: activeSession.sessionId,
    chunkCount: activeSession.chunkIndex,
    savedLocally: activeSession.chunkIndex > 0,
    retryPending: false,
    lastError: "",
  });
  activeSession.recorder.stop();
  return activeSession.stopPromise;
}

async function persistChunk(blob) {
  if (!activeSession) {
    return;
  }

  const session = activeSession;
  const chunkIndex = session.chunkIndex++;
  const writePromise = storeChunkBlob(session.sessionId, chunkIndex, blob).then(() =>
    touchStoredSession(session.sessionId, {
      chunkCount: session.chunkIndex,
      updatedAt: Date.now(),
      state: session.state === "recording" ? "recording" : "processing",
      lastError: "",
    })
  );

  session.pendingWrites.add(writePromise);

  try {
    await writePromise;
    await notifyHeartbeat(session.tabId);
    await notifyProgress(session.tabId, {
      phase: "recording",
      status: "Recording live audio",
      detail: `${session.chunkIndex} recovery chunk${session.chunkIndex === 1 ? "" : "s"} safely saved on this device.`,
      stage: "recording",
      terminal: false,
      sessionId: session.sessionId,
      chunkCount: session.chunkIndex,
      savedLocally: true,
      retryPending: false,
      lastError: "",
    });
  } finally {
    session.pendingWrites.delete(writePromise);
  }
}

async function waitForPendingWrites(session) {
  if (!session) {
    return;
  }

  const writes = Array.from(session.pendingWrites);
  if (!writes.length) {
    return;
  }

  await Promise.all(writes);
}

async function uploadStoredSession(sessionId) {
  const session = await getStoredSession(sessionId);
  if (!session) {
    throw new Error("Momentum could not find the saved meeting audio.");
  }

  const chunks = await getStoredChunks(sessionId);
  if (!chunks.length) {
    throw new Error("Momentum could not find any saved audio chunks for this meeting.");
  }

  const mimeType = session.mimeType || "audio/webm";
  const extension = getFileExtension(mimeType);
  const safeMeetingCode = sanitizeMeetingCode(session.meetingCode) || "meeting";
  const file = new File(
    chunks.map((chunk) => chunk.blob),
    `momentum_${safeMeetingCode}_${Date.now()}.${extension}`,
    { type: mimeType }
  );

  try {
    const directResult = await uploadAudioDirectlyToSupabase(file, session, mimeType);
    await clearStoredSession(sessionId);
    await reportQueueSummary();
    return directResult;
  } catch (_) {}

  const formData = new FormData();
  formData.append("file", file);
  formData.append("meetingCode", session.meetingCode || "");
  formData.append("meetingUrl", session.meetingUrl || "");
  formData.append("contentType", mimeType);
  formData.append("sessionId", session.sessionId);

  const response = await fetch(PROCESS_UPLOAD_URL, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error(await readErrorMessage(response, "Supabase audio storage failed."));
  }

  const result = await response.json();
  await clearStoredSession(sessionId);
  await reportQueueSummary();
  return result;
}

async function uploadAudioDirectlyToSupabase(file, session, mimeType) {
  const status = buildSessionStatus(session.sessionId);
  const payload = {
    title: buildMeetingTitle(session),
    summary: buildMeetingSummary(session, mimeType, file.size),
    transcript: null,
    clarity: 0,
    actionability: 0,
    audio_url: await fileToDataUrl(file),
    status,
  };

  const existing = await getExistingMeetingForSession(status);
  const response = existing?.id
    ? await fetch(`${SUPABASE_URL}/rest/v1/meetings?id=eq.${encodeURIComponent(existing.id)}`, {
        method: "PATCH",
        headers: buildSupabaseHeaders(true),
        body: JSON.stringify(payload),
      })
    : await fetch(`${SUPABASE_URL}/rest/v1/meetings`, {
        method: "POST",
        headers: buildSupabaseHeaders(true),
        body: JSON.stringify(payload),
      });

  if (!response.ok) {
    throw new Error(await readErrorMessage(response, "Supabase database storage failed."));
  }

  const data = await response.json();
  const meeting = Array.isArray(data) ? data[0] : data;
  if (!meeting?.id) {
    throw new Error("Supabase did not return the stored meeting row.");
  }

  return {
    meetingId: meeting.id,
    meetingTitle: meeting.title,
    storageMode: "database-inline",
  };
}

async function getExistingMeetingForSession(status) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/meetings?status=eq.${status}&select=id,title&limit=1`,
    {
      method: "GET",
      headers: buildSupabaseHeaders(false),
    }
  );

  if (!response.ok) {
    return null;
  }

  const data = await response.json();
  return Array.isArray(data) ? data[0] || null : null;
}

function buildSupabaseHeaders(returnRepresentation) {
  const headers = {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
    "Content-Type": "application/json",
  };

  if (returnRepresentation) {
    headers.Prefer = "return=representation";
  }

  return headers;
}

function buildMeetingTitle(session) {
  const code = sanitizeMeetingCode(session.meetingCode) || "meet-session";
  return `Audio captured for ${code}`;
}

function buildMeetingSummary(session, mimeType, bytes) {
  return [
    "Raw meeting audio was saved by Momentum.",
    "AI transcription and analysis can run later.",
    session.meetingUrl ? `Source: ${session.meetingUrl}` : "",
    `Format: ${mimeType}. Size: ${Math.max(1, Math.round(bytes / 1024))} KB.`,
    session.sessionId ? `Session: ${session.sessionId}.` : "",
  ]
    .filter(Boolean)
    .join(" ");
}

function buildSessionStatus(sessionId) {
  return sessionId ? `audio-uploaded:${sessionId}` : "audio-uploaded";
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error("FileReader could not encode the meeting audio."));
    reader.readAsDataURL(file);
  });
}

async function recoverPendingSessions() {
  if (activeSession) {
    return;
  }

  const sessions = await listStoredSessions();
  const recoverable = sessions
    .filter((session) => session?.sessionId && session.state !== "complete")
    .sort((left, right) => (left.createdAt || 0) - (right.createdAt || 0));

  await reportQueueSummary();

  for (const session of recoverable) {
    try {
      await updateStoredSessionState(session.sessionId, "uploading", { lastError: "" });
      await reportQueueSummary();
      await uploadStoredSession(session.sessionId);
    } catch (error) {
      await markSessionForRetry(session.sessionId, error.message);
      await reportQueueSummary();
    }
  }
}

async function markSessionForRetry(sessionId, errorMessage) {
  await updateStoredSessionState(sessionId, "pending_upload", {
    lastError: String(errorMessage || "Supabase audio upload failed.").slice(0, 500),
    updatedAt: Date.now(),
  });
}

function cleanupLiveSession() {
  if (!activeSession) {
    return;
  }

  activeSession.stream?.getTracks().forEach((track) => track.stop());
  activeSession = null;
}

function withTimeout(promise, timeoutMs, timeoutMessage) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeoutId = setTimeout(() => {
      if (settled) {
        return;
      }

      settled = true;
      reject(new Error(timeoutMessage));
    }, timeoutMs);

    Promise.resolve(promise)
      .then((value) => {
        if (settled) {
          return;
        }

        settled = true;
        clearTimeout(timeoutId);
        resolve(value);
      })
      .catch((error) => {
        if (settled) {
          return;
        }

        settled = true;
        clearTimeout(timeoutId);
        reject(error);
      });
  });
}

async function notifyHeartbeat(tabId) {
  await chrome.runtime.sendMessage({
    type: "SESSION_HEARTBEAT",
    tabId,
  });
}

async function notifyProgress(tabId, payload) {
  await chrome.runtime.sendMessage({
    type: "SESSION_PROGRESS",
    tabId,
    ...payload,
  });
}

async function reportQueueSummary() {
  const summary = await getPendingUploadSummary();
  await sendRuntimeMessage({
    type: "SYNC_QUEUE_SUMMARY",
    summary,
  }).catch(() => {});
}

async function getPendingUploadSummary() {
  const sessions = await listStoredSessions();
  const pendingSessions = sessions.filter((session) => session?.state === "pending_upload");
  const uploadingSessions = sessions.filter((session) => session?.state === "uploading");
  const latestErroredSession = [...sessions]
    .filter((session) => session?.lastError)
    .sort((left, right) => (right.updatedAt || 0) - (left.updatedAt || 0))[0];

  return {
    pendingCount: pendingSessions.length,
    uploadingCount: uploadingSessions.length,
    lastError: latestErroredSession?.lastError || "",
    updatedAt: Date.now(),
  };
}

function emptySummary() {
  return {
    pendingCount: 0,
    uploadingCount: 0,
    lastError: "",
    updatedAt: Date.now(),
  };
}

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;

      if (!db.objectStoreNames.contains(SESSION_STORE)) {
        db.createObjectStore(SESSION_STORE, { keyPath: "sessionId" });
      }

      if (!db.objectStoreNames.contains(CHUNK_STORE)) {
        const chunkStore = db.createObjectStore(CHUNK_STORE, { keyPath: "key" });
        chunkStore.createIndex("sessionId", "sessionId", { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedDB could not be opened."));
  });
}

async function withStore(storeName, mode, callback) {
  const db = await openDatabase();

  return await new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, mode);
    const store = transaction.objectStore(storeName);

    let result;
    transaction.oncomplete = () => {
      db.close();
      resolve(result);
    };
    transaction.onerror = () => {
      db.close();
      reject(transaction.error || new Error("IndexedDB transaction failed."));
    };
    transaction.onabort = () => {
      db.close();
      reject(transaction.error || new Error("IndexedDB transaction was aborted."));
    };

    try {
      const maybePromise = callback(store, transaction);
      Promise.resolve(maybePromise)
        .then((value) => {
          result = value;
        })
        .catch((error) => reject(error));
    } catch (error) {
      reject(error);
    }
  });
}

async function putRecord(storeName, value) {
  await withStore(storeName, "readwrite", (store) => {
    store.put(value);
  });
}

async function getRecord(storeName, key) {
  return await withStore(storeName, "readonly", (store) =>
    new Promise((resolve, reject) => {
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error || new Error("IndexedDB read failed."));
    })
  );
}

async function getAllRecords(storeName) {
  return await withStore(storeName, "readonly", (store) =>
    new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error || new Error("IndexedDB read failed."));
    })
  );
}

async function deleteRecord(storeName, key) {
  await withStore(storeName, "readwrite", (store) => {
    store.delete(key);
  });
}

async function upsertStoredSession(session) {
  const existing = await getStoredSession(session.sessionId);
  await putRecord(SESSION_STORE, {
    ...existing,
    ...session,
    updatedAt: Date.now(),
  });
}

async function touchStoredSession(sessionId, patch) {
  const existing = await getStoredSession(sessionId);
  if (!existing) {
    return;
  }

  await putRecord(SESSION_STORE, {
    ...existing,
    ...patch,
    updatedAt: Date.now(),
  });
}

async function updateStoredSessionState(sessionId, state, patch = {}) {
  await touchStoredSession(sessionId, {
    ...patch,
    state,
  });
}

async function getStoredSession(sessionId) {
  return await getRecord(SESSION_STORE, sessionId);
}

async function listStoredSessions() {
  return await getAllRecords(SESSION_STORE);
}

async function storeChunkBlob(sessionId, chunkIndex, blob) {
  await putRecord(CHUNK_STORE, {
    key: buildChunkKey(sessionId, chunkIndex),
    sessionId,
    chunkIndex,
    blob,
    createdAt: Date.now(),
  });
}

async function getStoredChunks(sessionId) {
  const chunks = await getAllRecords(CHUNK_STORE);
  return chunks
    .filter((chunk) => chunk.sessionId === sessionId)
    .sort((left, right) => left.chunkIndex - right.chunkIndex);
}

async function clearStoredSession(sessionId) {
  const chunks = await getStoredChunks(sessionId);

  for (const chunk of chunks) {
    await deleteRecord(CHUNK_STORE, chunk.key);
  }

  await deleteRecord(SESSION_STORE, sessionId);
}

function buildChunkKey(sessionId, chunkIndex) {
  return `${sessionId}:${String(chunkIndex).padStart(6, "0")}`;
}

function sanitizeMeetingCode(value) {
  return String(value || "").trim().replace(/[^a-z0-9-]/gi, "").slice(0, 32);
}

function getFileExtension(contentType) {
  const normalized = String(contentType || "").toLowerCase();

  if (normalized.includes("wav")) {
    return "wav";
  }

  if (normalized.includes("mp3") || normalized.includes("mpeg")) {
    return "mp3";
  }

  if (normalized.includes("m4a") || normalized.includes("mp4")) {
    return "m4a";
  }

  return "webm";
}

async function readErrorMessage(response, fallback) {
  const text = await response.text().catch(() => "");

  if (!text) {
    return fallback;
  }

  try {
    const data = JSON.parse(text);
    return data?.error?.message || data?.message || data?.error_description || fallback;
  } catch {
    return text.slice(0, 200);
  }
}

function sendRuntimeMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      resolve(response);
    });
  });
}
